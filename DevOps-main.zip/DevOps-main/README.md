# DevOps


This repository consists the skeleton of Jenkins script for Linux and Wondows VM's
