kill $(ps -ef|grep java|awk '{print $2}')

#Kills all the active process
